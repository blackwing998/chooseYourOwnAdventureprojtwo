//
//  ViewController.swift
//  sword shield mace
//
//  Created by James.Cotter on 1/31/19.
//  Copyright © 2019 James.Cotter. All rights reserved.
//
import UIKit

class ViewController: UIViewController {

    var didPlayerWin : Bool = false
    var didTheyTie : Bool = false
    var playerSelect : Int = 0
    var opponentSelect : Int = 0
    
    @IBOutlet weak var maceenemy: UIImageView!
    @IBOutlet weak var enemyshield: UIImageView!
    @IBOutlet weak var enemysword: UIImageView!
    
    @IBOutlet weak var playersword: UIImageView!
    @IBOutlet weak var playershield: UIImageView!
    @IBOutlet weak var playermace: UIImageView!
    
    @IBOutlet weak var gameover: UIImageView!
    @IBOutlet weak var winscreen: UIImageView!
    @IBOutlet weak var drawscreen: UIImageView!
    
    @IBAction func swordbuttonpressed(_ sender: Any) {
        // change player select value to 1
        playerSelect = 1
        // display player image in middle
        playersword.alpha = 1
        // run evilAI function
        evilAI()
        
    }
    
    @IBAction func shieldbuttonpreesed(_ sender: Any) {
        // change player select value to 2
        playerSelect = 2
        // display player image in middle
        playershield.alpha = 1
        // run evilAI function
        evilAI()
        
    }
    
    @IBAction func macebuttonpressed(_ sender: Any) {
        // change player select value to 3
        playerSelect = 3
        // display player image in middle
         playermace.alpha = 1        // run evilAI function
        evilAI()
    }
    func evilAI () {
        // pick a random number
        opponentSelect = Int.random (in: 1...3)
        // display image
        if opponentSelect == 1 {enemysword.alpha = 1}
        if opponentSelect == 2 {enemyshield.alpha = 1}
        if opponentSelect == 3 {maceenemy.alpha = 1}
        // run winOrLose function
        winOrLose()
    }
    
    func winOrLose () {
        // compare numbers
        if playerSelect == 1 {
            switch opponentSelect {
            case 1 :
                didTheyTie = true
                drawscreen.alpha = 1
                 winscreen.alpha = 0
                gameover.alpha = 0
            case 2 :
                didPlayerWin = false
                gameover.alpha = 1
                 winscreen.alpha = 0
                drawscreen.alpha = 0
            case 3 :
                didPlayerWin = true
                winscreen.alpha = 1
                gameover.alpha = 0
                drawscreen.alpha = 0
            default :
                break
            }
            
        }
        if playerSelect == 2 {
            switch opponentSelect {
            case 1 :
                didPlayerWin = true
                winscreen.alpha = 1
                gameover.alpha = 0
                 drawscreen.alpha = 0
            case 2 :
                didTheyTie = true
                drawscreen.alpha = 1
                gameover.alpha = 0
                 winscreen.alpha = 0
            case 3 :
                didPlayerWin = false
                gameover.alpha = 1
                 drawscreen.alpha = 0
                 winscreen.alpha = 0
            default :
                break
            }
            
        }
        if playerSelect == 3 {
            switch opponentSelect {
            case 1 :
                didPlayerWin = false
                gameover.alpha = 1
                winscreen.alpha = 0
                drawscreen.alpha = 0
            case 2 :
                didPlayerWin = true
                winscreen.alpha = 1
                drawscreen.alpha = 0
                gameover.alpha = 0
            case 3 :
                didTheyTie = true
                drawscreen.alpha = 1
                winscreen.alpha = 0
                gameover.alpha = 0
            default :
                break
            }
        }
        let timer = Timer.scheduledTimer(timeInterval: 5.0, target: self, selector: #selector(resetGame), userInfo: nil, repeats: false)
        // display win or lose text
        // run resetGame after 5 seconds
       // resetGame()
    }
    
    @objc func resetGame () {
        // reset variables
        print(didPlayerWin)
        didTheyTie = false
        didPlayerWin = false
        playerSelect = 0
        opponentSelect = 0
        gameover.alpha = 0
        winscreen.alpha = 0
        drawscreen.alpha = 0
        enemysword.alpha = 0
        enemyshield.alpha = 0
        maceenemy.alpha = 0
        playersword.alpha = 0
        playershield.alpha = 0
        playermace.alpha = 0
        
        // wipe screen
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    
}
